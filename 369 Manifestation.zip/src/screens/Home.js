import React from "react";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { nextday } from './ResetterReducer';
import { reset } from './CounterReducer';
import { replaced } from './DatesReducer';
import { replace } from './CounterReducer';
import { View, Image, ScrollView } from "react-native";
import AsyncStorage from '@react-native-async-storage/async-storage';
import {

  Button,
  Text,
  Section,
 
} from "react-native-rapi-ui";

export default function ({ navigation }) {
    const daily = useSelector(state => state.nextday);
    const dailyO = daily.nextday;
    const today = new Date();
    let todayO = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    const dispatch = useDispatch();
    
    if (todayO != dailyO) {
     dispatch(nextday(todayO));
        dispatch(reset());
    }

    let aCounter = null;




    asyncGet1 = async () => {
        try {
            aCounter = await AsyncStorage.getItem('aCounter');
            if (value !== null) {
                // value previously stored
                dispatch(replace(aCounter));
            }
            else {
                dispatch(replace(18));
            } 

        } catch (e) {
            console.log("error");
        }

        console.log(aCounter);
    }
    asyncGet2 = async () => {
        try {
            aNextday = await AsyncStorage.getItem('aNextday');
            if (value !== null) {
                // value previously stored
                dispatch(replaced(aNextday));
                console.log(("it worked"));
            } else {
                console.log('its null');
            }
        } catch (e) {
            console.log("error");
        }

        console.log(aNextday);
    }





    return (
 
      <View
        style={{
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "#FFFFFF",
        }}
      >
            <Section>
                <ScrollView
                    style={{
                        backgroundColor: "#FFFFFF",
                        paddingTop: 80,
                        
                    }}
                >
<Image
                        style={{
                            display: "flex",
                            alignSelf: 'center',
                            marginTop: 50,
                            height: 250,
                            marginBottom: 10,
                            width: 250,
                            alignItems: "center",


                        }}
                        source={require("./Logo.png")}
                        resizeMode="cover"
                    />   

              
                
               
                   
                  <Text fontWeight="bold" style={{ color:"#FFFFFF",  textAlign: "center", paddingTop: 30}}>
                      Welcome To 369 Manifestation
            </Text>
                  <Text fontWeight="bold" style={{ color: "#FFFFFF", textAlign: "center" }}>
                      Make All Of Your Dreams Come True!
                  </Text>
                  <Button
                      style={{
                          marginTop: 10
                      }}
                      color="#14E114"
                      text="Learn More"
                        onPress={() => { asyncGet1(); asyncGet2(); navigation.navigate("LearnMore");  }}
                      outline
            />
            <Button
              text="Go To Journal"
              onPress={() => {
                  asyncGet1(); asyncGet2();
                  navigation.navigate("Journal");
                  
              }}
              style={{
                  marginTop: 10,
                  
              }}color="#14E114"
                  outline
            />

            <Button
              text="See Your Completion Calendar"
                      color="#14E114"
                      outline
                        onPress={() => {
                            asyncGet1(); asyncGet2();
                  navigation.navigate("Calendar");
              }}
              style={{
                marginTop: 10,
              }}
                          />
                       
                      
                    </ScrollView>
        </Section>
      </View>
  
  );
}

