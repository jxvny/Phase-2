import { View } from 'react-native';
import { useSelector } from "react-redux";
import { Calendar } from 'react-native-calendars';
import {
	Layout,
	TopNav,
	Text,
	Section,
	SectionContent,
} from 'react-native-rapi-ui';
import { Ionicons } from '@expo/vector-icons';

export default function ({ navigation }) {
	const marked = useSelector(state => state.dates);
	let newDaysObject = {};
	let mark = marked.dates;	


	const markAllDays = () => {
			
			mark.forEach((day) => {
				newDaysObject[day] = {
					selected: true,
					marked: true
				};
			});	
	}
	
	return (
		<Layout>
			<TopNav
				middleContent="Completion Calendar"
				leftContent={
					<Ionicons name="chevron-back" size={20} />
				}
				leftAction={() => navigation.goBack()}
			/>
			<View
				style={{
					flex: 1,
					alignItems: "center",
					justifyContent: "center",
					backgroundColor: "#09323B",
				}}
			>
				<Section>
					<SectionContent>
						<Text fontWeight="bold" style={{ marginBottom: 10 }}> Try To Complete All Entries Everyday  </Text>
						<Calendar
							markingType={'dot'}
							markedDates={markAllDays(), newDaysObject}
							theme={{
								selectedDayBackgroundColor: '#00ff65',
                            }}
						/>
					</SectionContent>
				</Section>
			</View>
		</Layout>
	);
}


