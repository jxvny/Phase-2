// JavaScript source code

import { combineReducers, createStore } from 'redux';
import allReducers from './CombineReducers';


const rootReducer = allReducers;

const store = createStore(rootReducer)

export default store