const COMPLETE = "COMPLETE";
const NEWDAY = "NEWDAY";
const REPLACED = "REPLACED";

// Action creators
export const complete  = (ate) => ({
    type: COMPLETE,
    payload: ate,
})

export const newday = () => ({
    type: NEWDAY,
})
export const replaced = (props) => ({
    type: REPLACED,
    payload: props,
})


// Initial state
const initialState = {
    dates: []
}

// Root reducer
const datesReducer = (state = initialState, action) => {
    switch (action.type) {
        case COMPLETE:
            return {
                ...state,
                dates: [...state.dates, action.payload]
            }
        case REPLACED: 
            return {
                ...state,
                dates: [action.payload]
            }
        default:
            return state
    }
}

export default datesReducer