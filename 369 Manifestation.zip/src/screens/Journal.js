import React, { useState } from "react";
import { TextInput, View, TouchableOpacity, Alert, ScrollView } from "react-native";
import { useSelector } from "react-redux";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useDispatch } from "react-redux";
import { decrement } from './CounterReducer';
import { replace } from './CounterReducer';
import { complete } from './DatesReducer';
import {
  Layout,
  TopNav,
  Text,
  Section,
  SectionContent,
  Button,
} from "react-native-rapi-ui";
import { Ionicons } from "@expo/vector-icons";
import Entries from './Entries';

export default function ({ navigation }) {
    const counter = useSelector(state => state.counter);
    const marked = useSelector(state => state.dates);
    let mark = marked.dates;	
    let a = counter.counter;
    const [e, setE] = useState();
    const [entry, setEntry] = useState([]);
    const [type,setType] = useState();
    const [num, setNum] = useState(a);
    let aCounter = 18;
    let month = "";
    let today = new Date();
    if ((today.getMonth() + 1) <= 9) {
        month = "0" + (today.getMonth() + 1);
    } else {
        month = (today.getMonth() + 1);
    }
    let dateSetter = today.getFullYear() + '-' + (month) + '-' + today.getDate();

    const dispatch = useDispatch();

    const decrementCount = () => {
        console.log(aCounter);

        if (a >= 1) {
            dispatch(decrement());
            aCounter--;
        }
        if (a === 18) {
            setType('Morning ');
            setNum(2);
        }
        if (a === 17) {
            setType('Morning ');
            setNum(1);
        }
        if (a === 16) {
            setType('Afternoon ');
            setNum(6);
        }
        if (a === 15) {
            setType('Afternoon ');
            setNum(5);
        }
        if (a === 14) {
            setType('Afternoon ');
            setNum(4);
        }
        if (a === 13) {
            setType('Afternoon ');
            setNum(3);
        }
        if (a === 12) {
            setType('Afternoon ');
            setNum(2);
        }
        if (a === 11) {
            setType('Afternoon ');
            setNum(1);
        }
        if (a === 10) {
            setType('Evening ')
            setNum(9);
        }
        if (a === 9) {
            setType('Evening ')
            setNum(8);
        }
        if (a === 8) {
            setType('Evening ')
            setNum(7);
        }
        if (a === 7) {
            setType('Evening ')
            setNum(6);
        }
        if (a === 6) {
            setType('Evening ')
            setNum(5);
        }
        if (a === 5) {
            setType('Evening ')
            setNum(4);
        }
        if (a === 4) {
            setType('Evening ')
            setNum(3);
        }
        if (a === 3) {
            setType('Evening ')
            setNum(2);
        }
        if (a === 2) {
            setType('Evening ')
            setNum(1);
        }
        if (a === 1) {
            
           
            
            setNum(0);
            dispatch(complete(dateSetter));
            asyncSet2();
            navigation.navigate('Calendar');
        }
        asyncSet1(); 


    }

    asyncSet2 = async () => {
        try {
            await AsyncStorage.setItem('aNextday', JSON.stringify(mark));
        } catch (e) {
            //save error
            console.log("caught");
        }

        console.log("Done.")
    };

    asyncGet2 = async () => {
        try {
            aNextday = await AsyncStorage.getItem('aNextday');
            if (value !== null) {
                // value previously stored
                dispatch(replaced(aNextday));
            }
        } catch (e) {
            console.log("error");
        }

        console.log(aNextday);
    }

    const textChecker = () => {
        if (e == null) {
           Alert.alert("Cannot leave blank!");

        } else {
      decrementCount();         addEntry();
         
            asyncSet1();
        } }
  
    const addEntry = () => {
      
        setEntry([...entry, e])
        setE(null);
       
    };

    asyncSet1 = async () => {
        try {
            await AsyncStorage.setItem('aCounter', JSON.stringify(a));
        } catch (e) {
            //save error
            console.log("caught");
        }

        console.log("Done.")
    };


    asyncGet1 = async () => {
        try {
             aCounter = await AsyncStorage.getItem('aCounter');
            if (value !== null) {
                // value previously stored
                dispatch(replace(aCounter));
            }
        } catch (e) {
            console.log("error");
        }

        console.log(aCounter);
    }

    return (
     
    <Layout>
      <TopNav
        middleContent="Journal"
        leftContent={
          <Ionicons
            name="chevron-back"
            size={20}
          />
        }
        leftAction={() => navigation.goBack()}
                />
                <ScrollView contentContainerStyle={{
                    flexGrow: 1,
                    alignContent: "center",
                    justifyContent: "center",
                keyboardShouldPersistTaps: "never",
                backgroundColor: "#08080B"
                   
                }}>
      <View
        style={{
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "#09323B"
        }}
          >
              <Section>
                  <View
                      style={{
                        backgroundColor: "#09323B"
                            }}>
                            <ScrollView>
                        <SectionContent>
                            <Text
                                fontWeight="bold"
                                style={{
                                color: "#FFFFFF",
                                textAlign: "center",
                                margin: 15
                                }}
                            >
                                       Make All Of Your Dreams Come True           
                          </Text>
                          <View>
                              {
                                  entry.map((item, index) => {
                                      return (
                                           <TouchableOpacity key={index} >
                                          <Entries text={item} />
                                              </TouchableOpacity>
                                          )
                                        }
                                      )
                                    }
                          </View>
                          
                            


                            <View
                                  style={{
                                    borderColor: "#14E114",
                                    borderWidth: 2,
                                    marginTop: 20,
                                    marginBottom: 25,
                                    borderRadius: 10,

                                  }}
                          >
                             
                              <TextInput
                                  style={{
                                     
                                      padding: 10,
                                      fontSize: 14,
                                      height: 40,
                                      color: 'white',
                                  }}
                                  value={e}
                                  onChangeText={text => setE(text)}
                                  placeholder={"Enter Your Entry Here"}
                                  placeholderTextColor="#dbdbdb"
                                           
                              />
                            </View>
                       <Text style={{ 
                                      marginTop: 15,
                                      marginBottom: 10,
                                      maxWidth: '80%',
                                      color: "#FFFFFF"               
                                         }}> 
                                        {num} Remaining {type}Entries 
                                </Text> 
                          <Button
                              color="#14E114"
                              text="Add Entry"
                                        onPress={() => {   textChecker(); asyncGet1();}}
                              
                                    />
                                    <View style={{ padding: 50 }}/>
                                </SectionContent>
                                </ScrollView>
                    </View>
               </Section>               
                    </View>
                    </ScrollView>
            </Layout>
          

  );
}
