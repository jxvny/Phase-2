import counterReducer from "./CounterReducer";
import datesReducer from "./DatesReducer";
import { combineReducers } from "redux";
import resetterReducer from "./ResetterReducer";

const allReducers = combineReducers({
   counter: counterReducer,
    dates: datesReducer,
   nextday: resetterReducer,
});

export default allReducers;
