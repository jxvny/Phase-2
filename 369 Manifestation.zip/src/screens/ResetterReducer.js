// Actions
const NEXTDAY = "NEXTDAY";

// Action creators

export const nextday = (props) => ({
    type: NEXTDAY,
    payload: props,
})

// Initial state
const initialState = {
    nextday: null
}

// Root reducer
const resetterReducer = (state = initialState, action) => {
    switch (action.type) {
        case NEXTDAY:
            return {
                ...state,
                nextday: action.payload
            }
        default:
            return state
    }
}

export default resetterReducer