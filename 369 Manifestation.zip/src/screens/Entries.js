// JavaScript source code
import React, { useState } from "react";
import { TextInput, View, StyleSheet } from "react-native";
import {
    Layout,
    TopNav,
    Text,
    Section,
    SectionContent,
    Button,


} from "react-native-rapi-ui";


const Entries = (props) => {
    
 

   
    return (
        <View>
            <Text color="#FFFFFF" style={{
                margin: 5,
                maxWidth: '80%',
                color: "#FFFFFF"
            }}>{props.text}</Text>
           
            
        
    </View>



    )
}

export default Entries;