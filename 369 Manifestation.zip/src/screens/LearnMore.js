import React from "react";
import { View } from "react-native";
import {
  Layout,
  TopNav,
  Text,
    Section,
    SectionContent,
  Button,
} from "react-native-rapi-ui";
import { Ionicons } from "@expo/vector-icons";

export default function ({ navigation }) {
  return (
    <Layout>
      <TopNav
        middleContent="369 Manifestation Method"
        leftContent={
          <Ionicons
            name="chevron-back"
            size={20}
          />
        }
        leftAction={() => navigation.goBack()}
          /><View
              style={{
                  flex: 1,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: "#09323B",
              }}
          >
              <Section><View style={{
                  backgroundColor: "#09323B"
              }}>
                  <SectionContent>

                      <Text fontWeight="bold" style={{ color: "#FFFFFF", textAlign: "center" }}>
                          The 369 method has been recieving a tremendous amount of recognition lately as the results are absolutley mind blowning. The method is quite simple, think of a goal, dream, or something you want. It can be a broad as "I want to be whealthy" or as detailed as "I want to pass my nursing exam and become a nurse". Once you have decided what you want to manifest, you have 3 times a day when you need to make entries, three times in the morning, six times in the afternoon, and nine times at night. 
                      </Text>
                      <Text fontWeight="bold" style={{ color: "#FFFFFF", textAlign: "center", marginTop: 10, }}>
                          In the Morning,
                      </Text>
                      <Text fontWeight="bold" style={{ color: "#FFFFFF", textAlign: "center" }}>
                          Make three entries saying "I want to...", For example "I want to be whealthy" three times.

                      </Text>
                      <Text fontWeight="bold" style={{ color: "#FFFFFF", textAlign: "center", marginTop: 10, }}>
                          In the Afternoon,
                      </Text>
                      <Text fontWeight="bold" style={{ color: "#FFFFFF", textAlign: "center" }}>
                          Make six entries saying "I will...", For example "I will become whealthy" six times.
                      </Text>
                      <Text fontWeight="bold" style={{ color: "#FFFFFF", textAlign: "center", marginTop: 10, }}>
                          In the Evening,
                      </Text>
                      <Text fontWeight="bold" style={{ color: "#FFFFFF", textAlign: "center" }}>
                          Make nine entries saying "I am/have...", For example "I am whealthy" nine times.
                      </Text>
                      
                          <Button
                              text="Go To Journal"
                              onPress={() => {
                                  navigation.navigate("Journal");
                              }}
                              style={{
                                  marginTop: 30,

                              }} color="#14E114"
                              outline
                          />
              

                  </SectionContent></View>
              </Section>
          </View>
    </Layout>
  );
}
 