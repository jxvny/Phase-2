// Actions
const INCREMENT = "INCREMENT";
const DECREMENT = "DECREMENT";
const RESET = "RESET";
const REPLACE = "REPLACE";

// Action creators
export const increment = () => ({
    type: INCREMENT,
})

export const decrement = () => ({
    type: DECREMENT,
})

export const reset = () => ({
    type: RESET,
})

export const replace = (props) => ({
    type: REPLACE,
    payload: props,
})

// Initial state
const initialState = {
    counter: 18
}

// Root reducer
const counterReducer = (state = initialState, action) => {
    switch (action.type) {
        case INCREMENT:
            return {
                ...state,
                counter: state.counter + 1
            }
        case DECREMENT:
            return {
                ...state,
                counter: state.counter - 1
            }
        case RESET:
            return {
                ...state,
                counter: 18
            }
        case REPLACE:
            return {
                ...state,
                counter: action.payload
            }
        default:
            return state
    }
}

export default counterReducer