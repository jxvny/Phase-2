import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Home from "../screens/Home";
import Journal from "../screens/Journal";
import Calendar from "../screens/Calendar";
import LearnMore from "../screens/LearnMore";

const MainStack = createNativeStackNavigator();
const Main = () => {
  return (
    <MainStack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
          <MainStack.Screen name="Home" component={Home} />
          <MainStack.Screen name="Journal" component={Journal} />
          <MainStack.Screen name="Calendar" component={Calendar} />
          <MainStack.Screen name="LearnMore" component={LearnMore} />
    </MainStack.Navigator>
  );
};


export default () => {
  return (
    <NavigationContainer>
      <Main />
    </NavigationContainer>
  );
};
